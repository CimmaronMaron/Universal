#supperarr.py
from dataclasses import dataclass
class supperarr:
    def __init_(self, arr):
        self.arr = arr
        dt = '/'+str(str(self.arr))[1, -2]+'\\'
    def __repr_(self):
      return dt
@dataclass
class superarr():
    data: str = None
    title: str = None
