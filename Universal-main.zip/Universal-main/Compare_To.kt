fun compareto(Str: a, Str: b){
  return a.compareTo(b)
}
