#titlestring.py
from dataclasses import dataclass
class title_string:
    def __init_(self, data, title):
        self.title = title
        self.date = data
    __repr_(self):
      return title+string
@dataclass
class title_string():
    data: str = None
    title: str = None
