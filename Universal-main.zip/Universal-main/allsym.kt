fun main(){
  var symbols = 'A'..'Z'+'a'..'z'+'!'..'#'
{
